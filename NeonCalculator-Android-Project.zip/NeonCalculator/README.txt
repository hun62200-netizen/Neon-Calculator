NEON CALCULATOR - ANDROID PROJECT

This is the Android Studio source project, not a precompiled APK.

To build an APK:
1. Install Android Studio on a computer.
2. Open this NeonCalculator folder as a project.
3. Let Android Studio sync Gradle and install any requested Android SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When finished, use the notification's Locate link. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer the APK to your Android phone and open it. You may need to allow installation from that source in Android settings.

No network permission is requested. Calculator UI is bundled locally in the app.
